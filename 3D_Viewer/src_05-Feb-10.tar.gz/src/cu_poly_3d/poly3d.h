//
//  file:  poly3d.h
//
//  Common header for poly3d.cu
//
//  RTK, 17-Nov-2009
//  Last update:  02-Dec-2009
//
///////////////////////////////////////////////////////////////

#ifndef POLY_3D_H
#define POLY_3D_H

#define DEBUG

#endif

