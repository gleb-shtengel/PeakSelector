//
//  file:  convol_d.h
//
//  Common header for convol_d.cu
//
//  RTK, 18-Dec-2009
//  Last update:  23-Dec-2009
//
///////////////////////////////////////////////////////////////

#ifndef CONVOL_D_H
#define CONVOL_D_H

//#define DEBUG
#define MAX_NK 81

#endif

