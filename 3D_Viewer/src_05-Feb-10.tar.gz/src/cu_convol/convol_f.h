//
//  file:  convol_f.h
//
//  Common header for convol_f.cu
//
//  RTK, 18-Dec-2009
//  Last update:  18-Dec-2009
//
///////////////////////////////////////////////////////////////

#ifndef CONVOL_F_H
#define CONVOL_F_H

//#define DEBUG
#define MAX_NK 111

#endif

